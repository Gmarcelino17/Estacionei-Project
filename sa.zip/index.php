<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="UTF-8">
		<title> Login</title>
		
		
	</head>

	<body>
    
        <a href="app/">
            <input type="button" value="ACESSO">
        </a>
		
	</body>

</html>